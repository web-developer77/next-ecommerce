import React,{useEffect,useState} from 'react'
import { Row, Col } from 'react-bootstrap'
import Slider from 'react-slick'
import { Dispatch } from "redux";
import { Product } from '@views/elements'
import { GetProducts_getPrdProductList_result } from '@services/productsService/__generated__/GetProducts'
import referenceService from "@services/referenceService";
import { useAppDispatch, useAppSelector } from "@redux/hooks";
import { GetCategoryByParentId_getMstCategoryByParentId_result } from "@services/referenceService/__generated__/GetCategoryByParentId";
import { GetPrdCategory_getPrdCategoryList_result } from "@services/referenceService/__generated__/GetPrdCategory";
import productsService from '@services/productsService'

import {
  setProvinceList,
  setCityList,
  setSuburbList,
  setMainCategoryList,
  setSubCategoryList,
  setCategoryId,
  setNewsSliderKey,
  setPrdCategoryList,
} from "@views/containers/Reference/ReferenceSlice";
const settings = {
  infinite: true,
  slidesToShow: 4,
  slidesToScroll: 1,
  dots: false,
  arrows: true,
  responsive: [
    {
      breakpoint: 1600,
      settings: {
        slidesToShow: 3,
      },
    },
    {
      breakpoint: 1200,
      settings: {
        slidesToShow: 1,
      },
    },
    {
      breakpoint: 992,
      settings: {
        slidesToShow: 2,
      },
    },
    {
      breakpoint: 768,
      settings: {
        slidesToShow: 1,
      },
    },
  ],
}

const settings1 = {
  infinite: true,
  slidesToShow: 1,
  slidesToScroll: 1,
  dots: true,
  arrows: false,
  fade: true,
}

const categorieImages = [
  '/assets/img/product-category-image-1.jpg',
  '/assets/img/product-category-image-2.jpg',
  '/assets/img/product-category-image-3.jpg',
  '/assets/img/product-category-image-4.jpg',
  '/assets/img/product-category-image-5.jpg',
]

const categoryBackClassnames = [
  'dtw',
  'ad',
  'artgift',
  'am',
  'che',
]
const actionDispatch = (dispatch: Dispatch) => ({
  setSubCategoryList: (
    data: GetCategoryByParentId_getMstCategoryByParentId_result[]
  ) => dispatch(setSubCategoryList(data)),
  setPrdCategoryList: (data: GetPrdCategory_getPrdCategoryList_result[]) =>
    dispatch(setPrdCategoryList(data)),
});
interface IProductsProps {
  item: {
    categoryName: String,
    products: (GetProducts_getPrdProductList_result | null)[]
  }
}

const ProductSection = (props: IProductsProps) => {
  const { item } = props
  console.log(item,'itemitem')
  const categoryId = Number(process.env.NEXT_PUBLIC_DEFAULT_CATEGORY_ID);
  const [products, setProductList] = useState<Array<string>>([])
  const {
    setSubCategoryList,
    setPrdCategoryList,
  } = actionDispatch(useAppDispatch());
  const [catdata, setCatdata] = useState<any>([]);
  const fetchProductList = async (
    page: number,
    categoryId: number | null,
    scopeId: number | null,
    salesTypeId: number | null,
    status: boolean | null,
    domainCategoryIds: String | null,
    typeId: number | null,
    searchText?: string | null,
  ) => {
    // setLoading(true)
    const result = await productsService
      .getPrdProductList(
        searchText || null,
        null,
        categoryId==1447?null:categoryId,
        domainCategoryIds,
        null,
        null,
        null,
        0,
        10,
        page || 1,
      )
      .catch((err) => {
        console.log('Error', err)
      })
    console.log(result,'resusdsdjkasndjaskdnlt')
    // setLoading(false)
    let res: any = result
    if (res?.success) {
      setProductList(res.result)
    }
  }
  useEffect(() => {
    /* init search */
    // if (!cityList || !cityList.length) fetchCityList()
    // if (!suburbList || !suburbList.length) fetchSuburbList()

    /* init category */
    // if (!mainCategoryList || !mainCategoryList.length)
    fetchProductList(
      1,
      categoryId,
      1,
      1,
      true,
      '',
      1,
    )
    if(categoryId == 1447){
      fetchPrdCategoryList();
    }
    else{
      fetchMainCategoryList();
    }
     
    /* Agreement prd category */
    // if (!prdCategoryList || !prdCategoryList.length) 
    fetchPrdCategoryList();
  }, [props]);
  const fetchSubCategoryList = async (categoryId: number) => {
    const result = await referenceService.getCategoryListByParentId(1402);
    console.log(result,'resultresultresultresult')
    if (result) {
      setSubCategoryList(result);
    }
  };
  const fetchPrdCategoryList = async () => {
    const result = await referenceService.getPrdCategoryList(null, 1, 100);
    if (result) {
      setCatdata(result)
      setPrdCategoryList(result);
    }
  };

  const fetchMainCategoryList = async () => {
    const result = await referenceService.getMainCategoryList();
    if (result) {
      setMainCategoryList(result);
      fetchSubCategoryList(categoryId);
    }
  };

  return (
    <Row>
      <Col md={4} xs={12}>
        <div className="product-main-category slider-category">
          {/* <Slider {...settings1}> */}
            {
              catdata.length > 0 && catdata.map(items=>
                <div className="product-main-category-box">
                <img
                  src={categorieImages[Math.floor(Math.random() * (5))]}
                  className="img-responsive"
                  alt=""
                  width="584"
                  height="414"
                />
                <div className="product-category-title">
                  <h3>{items.categoryName}</h3>
                </div>
              </div>
                )
            }
           
            {/* <div className="product-main-category-box">
              <img
                src={categorieImages[Math.floor(Math.random() * (5))]}
                className="img-responsive"
                alt=""
                width="584"
                height="414"
              />
              <div className="product-category-title">
                <h3>{catdata.categoryName}</h3>
              </div>
            </div> */}
          {/* </Slider> */}
        </div>
      </Col>
      <Col md={8} xs={12}>
        <div className="product-sub-category slider-sub-category">
          <Slider {...settings}>
            {item.products.map((product, i) => (
              <Product product={product} key={i} />
            ))}
          </Slider>
        </div>
      </Col>
    </Row>
  )
}

export default ProductSection
